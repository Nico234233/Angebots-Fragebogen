<?php
// Standardindex für das Theme
get_header();
?>


<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mein Theme</title>
    <link rel="stylesheet" href="style.css">
    <?php wp_head(); ?>
</head>   
<body>
    <div class="container">
        <!-- Fortschrittsanzeige -->
        <div class="progress-bar">
            <div class="progress" id="progress"></div>
        </div>
        <div class="progress-text" id="progress-text">0% abgeschlossen</div>

        <!-- Frage 1 -->
        <div id="question1">
            <h1>In welchem Bundesland leben Sie?</h1>
            <div class="option-container">
                <div class="option" onclick="selectOption(this, 2, 15)">Nordrhein-Westfalen</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Hessen</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Bremen</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Schleswig-Holstein</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Baden-Württemberg</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Rheinland-Pfalz</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Niedersachsen</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Hamburg</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Mecklenburg-Vorpommern</div>
                <div class="option" onclick="selectOption(this, 2, 15)">Ich lebe in einem anderen Bundesland</div>
            </div>
        </div>

        <!-- Frage 2 -->
        <div id="question2" class="hidden">
            <h1>In welchem Baustellentyp soll Ihr Projekt realisiert werden?</h1>
            <div class="option-container">
                <div class="option" onclick="selectOption(this, 3, 30)">Neubau</div>
                <div class="option" onclick="selectOption(this, 3, 30)">Altbau</div>
                <div class="option" onclick="selectOption(this, 3, 30)">Gewerbeobjekt</div>
                <div class="option" onclick="selectOption(this, 3, 30)">Sonderbauten</div>
                <div class="option" onclick="selectOption(this, 3, 30)">Kellerausbau</div>
                <div class="option" onclick="selectOption(this, 3, 30)">Dachausbau</div>
                <div class="option" onclick="selectOption(this, 3, 30)">Ich bin mir nicht sicher und benötige Beratung</div>
            </div>
            <div class="button-container">
                <button class="back-btn" onclick="prevQuestion(1, 0)">Zurück</button>
            </div>
        </div>

        <!-- Frage 3 -->
        <div id="question3" class="hidden">
            <h1>Wie groß ist Ihr Projekt?</h1>
            <div class="option-container">
                <div class="option" onclick="selectOption(this, 4, 45)">Kleines Projekt – Ein einzelner Raum</div>
                <div class="option" onclick="selectOption(this, 4, 45)">Mittleres Projekt – Mehrere Räume</div>
                <div class="option" onclick="selectOption(this, 4, 45)">Großes Projekt – Eine komplette Wohnung oder Etage</div>
                <div class="option" onclick="selectOption(this, 4, 45)">Sehr großes Projekt – Ein ganzes Haus oder Bürogebäude</div>
                <div class="option" onclick="selectOption(this, 4, 45)">Spezialprojekt – Individuelle Arbeiten</div>
                <div class="option" onclick="selectOption(this, 4, 45)">Unklar – Ich bin mir nicht sicher und benötige Beratung</div>
            </div>
            <div class="button-container">
                <button class="back-btn" onclick="prevQuestion(2, 30)">Zurück</button>
            </div>
        </div>

       <!-- Frage 4: Wunschtermin mit Schnellauswahl -->
<div id="question4" class="hidden">
    <h1>Wann soll das Projekt starten?</h1>
    <div class="date-container">
        <label for="start-date">🗓 Projektstart:</label>
        <input type="date" id="start-date" placeholder="Wählen Sie das Startdatum">
    </div>

    <h1>Wann soll das Projekt abgeschlossen sein?</h1>
    <div class="date-container">
        <label for="end-date">🏁 Projektabschluss:</label>
        <input type="date" id="end-date" placeholder="Wählen Sie das Abschlussdatum">
    </div>

    <!-- Schnellauswahl-Buttons -->
    <div class="quick-select-container">
        <p style="text-align: center; margin-bottom: 10px; font-size: 0.95em;">
            Oder wählen Sie eine der folgenden Optionen:
        </p>
        <div class="option-container">
    <div class="time-option" onclick="setQuickDate(0, 14)">Sofort starten<br>(2 Wochen)</div>
<div class="time-option" onclick="setQuickDate(14, 30)">In 2 Wochen<br>(1 Monat)</div>
<div class="time-option" onclick="setQuickDate(30, 60)">Nächster Monat<br>(2 Monate)</div>
</div>

    </div>

    <!-- Fehlermeldung -->
    <div id="date-error" style="color: #d32f2f; display: none; margin-top: 10px;">
        Bitte wählen Sie ein gültiges Start- und Abschlussdatum. Oder wählen Sie eine der drei Möglichkeiten und klicken Sie dann auf Weiter. 
    </div>

    <!-- Buttons -->
    <div class="button-container">
        <button class="back-btn" onclick="prevQuestion(3, 45)">Zurück</button>
        <button class="btn" onclick="validateDates()">Weiter</button>
    </div>
</div>



       <!-- Frage 5 -->
<div id="question5" class="hidden">
    <h1>Wo soll das Bauprojekt realisiert werden?</h1>

    <div class="input-grid">
    <label for="plz">Postleitzahl (PLZ)</label>
    <input type="text" id="plz" placeholder="PLZ eingeben">
    <div id="plz-error" class="error" style="display: none; color: #d32f2f; font-size: 0.85em; margin-top: 5px;"></div>
</div>

<div class="input-grid"“>
    <label for="ort">Ort</label>
    <input type="text" id="ort" placeholder="Ort eingeben">
    <div id="ort-error" class="error" style="display: none; color: #d32f2f; font-size: 0.85em; margin-top: 5px;"></div>
</div>

<div class="input-grid">
    <label for="strasse">Straße</label>
    <input type="text" id="strasse" placeholder="Straße eingeben">
    <div id="strasse-error" class="error" style="display: none; color: #d32f2f; font-size: 0.85em; margin-top: 5px;"></div>
</div>

<div class="input-grid">
    <label for="hausnummer">Hausnummer</label>
    <input type="text" id="hausnummer" placeholder="Hausnummer eingeben">
    <div id="hausnummer-error" class="error" style="display: none; color: #d32f2f; font-size: 0.85em; margin-top: 5px;"></div>
</div>


    <!-- Fehlermeldung -->
    <div id="address-error" style="display: none;">Bitte füllen Sie alle Felder aus.</div>

    <!-- Buttons -->
    <div class="button-container">
        <button class="back-btn" onclick="prevQuestion(4, 45)">Zurück</button>
        <button class="btn" onclick="validateAddress()">Weiter</button>
    </div>
</div>


        <!-- Frage 6 -->
        <div id="question6" class="hidden">
            <h1>Wir prüfen jetzt, ob Ihr Angebot in Ihrer Region verfügbar ist…</h1>
            <div style="text-align: center;">
                <div id="loader" class="loader"></div>
            </div>
        </div>

        <!-- Frage 7 -->
        <div id="question7" class="hidden">
            <h1>🎉 Prüfung erfolgreich!</h1>
            <p style="text-align: center;">Ihre Angaben wurden erfolgreich geprüft.</p>
            <div class="button-container">
                <button class="btn" onclick="nextQuestion(8, 80)">Weiter</button>
            </div>
        </div>

       <!-- Frage 8: Wie dürfen wir Sie ansprechen -->
<div id="question8" class="hidden">
    <h1>Wie dürfen wir Sie ansprechen?</h1>
    <input type="text" id="name" placeholder="Vor- und Nachname">
    <!-- Fehlermeldung in Rot -->
    <div id="name-error" class="error" style="display: none; color: #d32f2f; font-size: 0.9em; margin-top: 5px;">
        Bitte geben Sie Ihren Vor- und Nachnamen ein.
    </div>
    <div class="button-container">
        <button class="btn" onclick="validateName()">Weiter</button>
    </div>
</div>



        <!-- Frage 9 -->
        <div id="question9" class="hidden">
            <h1>Wie möchten Sie kontaktiert werden?</h1>
            <input type="text" id="phone" placeholder="Telefonnummer">
<div id="phone-error" style="color: #d32f2f; display: none;">Bitte geben Sie eine gültige Telefonnummer ein.</div>
            <div class="button-container">
                <button class="btn" onclick="validatePhone()">Weiter</button>
            </div>
        </div>

        <!-- Frage 10 -->
        <div id="question10" class="hidden">
            <h1>Ihre E-Mail-Adresse</h1>
            <input type="email" id="email" placeholder="E-Mail-Adresse">
<div id="email-error" style="color: #d32f2f; display: none;">Bitte geben Sie eine gültige E-Mail-Adresse ein.</div>
            <div class="button-container">
                <button class="btn" onclick="validateEmail()">Weiter</button>
            </div>
        </div>

        <!-- Abschlussfrage -->
        <div id="question11" class="hidden">
            <h1>🎉 Vielen Dank für Ihre Angaben!</h1>
            <p>Wir erstellen jetzt Ihr individuelles Angebot und melden uns in Kürze.</p>
        </div>
    </div>

    <?php wp_footer(); ?>
</body>
<script>

function validateInputField(fieldId, errorId, errorMessage) {
    const inputField = document.getElementById(fieldId);
    const errorField = document.getElementById(errorId);
    
    inputField.addEventListener('input', () => {
        if (inputField.value.trim() === '') {
            errorField.style.display = 'block';
            errorField.textContent = errorMessage;
        } else {
            errorField.style.display = 'none';
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    validateInputField('plz', 'address-error', 'PLZ darf nicht leer sein.');
    validateInputField('ort', 'address-error', 'Ort darf nicht leer sein.');
    validateInputField('strasse', 'address-error', 'Straße darf nicht leer sein.');
    validateInputField('hausnummer', 'address-error', 'Hausnummer darf nicht leer sein.');
});



function ensureHiddenClasses() {
    const allQuestions = document.querySelectorAll('[id^="question"]');
    allQuestions.forEach((question) => {
        if (question.id !== 'question1') {
            question.classList.add('hidden'); // Stelle sicher, dass hidden gesetzt ist
        }
    });
    console.log('Alle Fragen wurden überprüft und korrekt versteckt.');
}

// Beim Seitenstart ausführen
document.addEventListener('DOMContentLoaded', () => {
    ensureHiddenClasses();
    showQuestion(1); // Starte mit Frage 1
    updateProgressBar(0);
});


function setQuickDate(startDays, endDays) {
    const today = new Date();
    const startDate = new Date(today);
    startDate.setDate(today.getDate() + startDays);

    const endDate = new Date(today);
    endDate.setDate(today.getDate() + endDays);

    // Setze die Werte in die Datumsfelder
    document.getElementById('start-date').value = startDate.toISOString().split('T')[0];
    document.getElementById('end-date').value = endDate.toISOString().split('T')[0];
}

function validatePhone() {
    const phoneInput = document.getElementById('phone').value.trim(); // Telefonnummer holen und Leerzeichen entfernen
    const phoneError = document.getElementById('phone-error');
    const phoneRegex = /^\+?[0-9\s\-]+$/; // Einfache Regex für Telefonnummern

    // Validierung der Eingabe
    if (!phoneInput) {
        phoneError.textContent = 'Bitte geben Sie Ihre Telefonnummer ein.';
        phoneError.style.display = 'block';
        return;
    } else if (!phoneRegex.test(phoneInput)) {
        phoneError.textContent = 'Bitte geben Sie eine gültige Telefonnummer ein.';
        phoneError.style.display = 'block';
        return;
    }

    // Fehler ausblenden und zur nächsten Frage navigieren
    phoneError.style.display = 'none';
    nextQuestion(10, 90); // Weiter zur nächsten Frage (Frage 10) und Fortschritt aktualisieren
}


function validateName() {
    const nameInput = document.getElementById('name').value.trim();
    const nameError = document.getElementById('name-error');

    if (!nameInput) {
        nameError.style.display = 'block'; // Fehlermeldung anzeigen
        nameError.textContent = 'Bitte geben Sie Ihren Vor- und Nachnamen ein.';
    } else {
        nameError.style.display = 'none'; // Fehlermeldung verstecken
        nextQuestion(9, 90); // Weiter zur nächsten Frage (Frage 9)
    }
}




function selectOption(element, nextId, progress) {
    // Alle Optionen in der aktuellen Frage zurücksetzen
    const options = element.parentElement.querySelectorAll('.option');
    options.forEach(option => option.classList.remove('selected'));

    // Gewählte Option hervorheben
    element.classList.add('selected');

    // Zur nächsten Frage navigieren
    nextQuestion(nextId, progress);
}


function updateProgressBar(percentage) {
    const progressBar = document.getElementById('progress');
    const progressText = document.getElementById('progress-text');
    
    progressBar.style.width = `${percentage}%`;

    // Motivierenden Text anzeigen
    if (percentage < 100) {
        progressText.innerText = `${percentage}% abgeschlossen – nur noch wenige Schritte!`;
    } else {
        progressText.innerText = `🎉 100% abgeschlossen – Vielen Dank!`;
    }
}


// Alle Fragen verstecken
function hideAllQuestions() {
    const questions = document.querySelectorAll('[id^="question"]');
    questions.forEach(question => question.classList.add('hidden'));
}

// Eine bestimmte Frage anzeigen und Fokus setzen
function showQuestion(questionId) {
    const question = document.getElementById(`question${questionId}`);
    if (question) {
        question.classList.remove('hidden');
        const questionHeader = question.querySelector('h1');
        if (questionHeader) {
            questionHeader.focus();
        }
    }
}

// Zu einer bestimmten Frage navigieren
function nextQuestion(nextId, progress) {
    hideAllQuestions(); // Versteckt alle Fragen
    showQuestion(nextId); // Zeigt die gewünschte Frage
    updateProgressBar(progress); // Fortschrittsanzeige aktualisieren

    // Automatische Weiterleitung bei Frage 6
    if (nextId === 6) {
        const loader = document.getElementById('loader');
        if (loader) {
            loader.style.display = 'block'; // Ladeanimation anzeigen
        }
        setTimeout(() => {
            if (loader) {
                loader.style.display = 'none'; // Ladeanimation ausblenden
            }
            nextQuestion(7, 70); // Weiter zu Frage 7
        }, 3000); // Simulierte Ladezeit von 3 Sekunden
    }
}

// Zur vorherigen Frage navigieren
function prevQuestion(prevId, progress) {
    hideAllQuestions(); // Versteckt alle Fragen
    showQuestion(prevId); // Zeigt die vorherige Frage
    updateProgressBar(progress); // Fortschrittsanzeige aktualisieren
}

// Validierung der Datumsangaben
function validateDates() {
    const startDateInput = document.getElementById('start-date');
    const endDateInput = document.getElementById('end-date');
    const error = document.getElementById('date-error');
    const today = new Date().toISOString().split('T')[0];

    const startDate = new Date(startDateInput.value);
    const endDate = new Date(endDateInput.value);

    if (!startDateInput.value || !endDateInput.value) {
        error.textContent = 'Bitte wählen Sie sowohl ein Start- als auch ein Abschlussdatum. Oder wählen Sie eine der drei Möglichkeiten und klicken Sie dann auf Weiter.' ;
        error.style.display = 'block';
        return;
    }

    if (startDateInput.value < today) {
        error.textContent = 'Das Startdatum darf nicht in der Vergangenheit liegen.';
        error.style.display = 'block';
        return;
    }

    if (endDate <= startDate) {
        error.textContent = 'Das Abschlussdatum muss nach dem Startdatum liegen.';
        error.style.display = 'block';
        return;
    }

    error.style.display = 'none'; // Fehler ausblenden
    nextQuestion(5, 60); // Weiter zur nächsten Frage
}

function validateAddress() {
    const plz = document.getElementById('plz').value.trim();
    const ort = document.getElementById('ort').value.trim();
    const strasse = document.getElementById('strasse').value.trim();
    const hausnummer = document.getElementById('hausnummer').value.trim();

    // Fehlermeldungen zurücksetzen
    document.getElementById('plz-error').style.display = 'none';
    document.getElementById('ort-error').style.display = 'none';
    document.getElementById('strasse-error').style.display = 'none';
    document.getElementById('hausnummer-error').style.display = 'none';

    let hasError = false;

    // PLZ validieren
    if (!plz) {
        document.getElementById('plz-error').textContent = 'Bitte geben Sie eine gültige PLZ ein.';
        document.getElementById('plz-error').style.display = 'block';
        hasError = true;
    }

    // Ort validieren
    if (!ort) {
        document.getElementById('ort-error').textContent = 'Bitte geben Sie einen Ort ein.';
        document.getElementById('ort-error').style.display = 'block';
        hasError = true;
    }

    // Straße validieren
    if (!strasse) {
        document.getElementById('strasse-error').textContent = 'Bitte geben Sie eine Straße ein.';
        document.getElementById('strasse-error').style.display = 'block';
        hasError = true;
    }

    // Hausnummer validieren
    if (!hausnummer) {
        document.getElementById('hausnummer-error').textContent = 'Bitte geben Sie eine Hausnummer ein.';
        document.getElementById('hausnummer-error').style.display = 'block';
        hasError = true;
    }

    // Nur weiter, wenn alle Felder ausgefüllt sind
    if (!hasError) {
        nextQuestion(6, 70);
    }
}


// Validierung des Formulars in Frage 8
function validateForm8() {
    const anrede = document.querySelector('input[name="anrede"]:checked');
    const name = document.getElementById('name').value.trim();
    const error = document.getElementById('form8-error');

    if (!anrede || !name) {
        error.textContent = 'Bitte füllen Sie alle Felder aus.';
        error.style.display = 'block';
        return;
    }

    error.style.display = 'none'; // Fehler ausblenden
    nextQuestion(9, 80); // Weiter zur nächsten Frage
}

// Validierung der Telefonnummer und Kontaktmethode
let selectedContactMethod = null;

function setContactMethod(method) {
    selectedContactMethod = method;

    // Visuelle Hervorhebung der Auswahl
    const options = document.querySelectorAll('#question9 .option');
    options.forEach(option => {
        option.style.background = '#f5faff'; // Standardfarbe zurücksetzen
        option.style.color = '#2196f3'; // Textfarbe zurücksetzen
    });

    const selectedOption = Array.from(options).find(option => option.textContent === method);
    if (selectedOption) {
        selectedOption.style.background = '#2196f3'; // Markierung
        selectedOption.style.color = '#fff'; // Textfarbe
    }
}

function validateContact() {
    const phone = document.getElementById('phone').value.trim();
    const phoneError = document.getElementById('phone-error');
    const contactMethodError = document.getElementById('contact-method-error');
    const phoneRegex = /^\+?[0-9\s\-]+$/;

    // Telefonnummer validieren
    if (!phone || !phoneRegex.test(phone)) {
        phoneError.textContent = 'Bitte geben Sie eine gültige Telefonnummer ein.';
        phoneError.style.display = 'block';
        return;
    }
    phoneError.style.display = 'none';

    // Kontaktmethode validieren
    if (!selectedContactMethod) {
        contactMethodError.textContent = 'Bitte wählen Sie eine Kontaktmethode aus.';
        contactMethodError.style.display = 'block';
        return;
    }
    contactMethodError.style.display = 'none';

    nextQuestion(10, 90); // Weiter zur nächsten Frage
}

function validateEmail() {
    const emailInput = document.getElementById('email').value.trim(); // Wert aus Eingabefeld holen
    const emailError = document.getElementById('email-error'); // Fehlermeldungselement
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Einfaches Regex für gültige E-Mail-Adressen

    // Validierung der Eingabe
    if (!emailInput) {
        emailError.textContent = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
        emailError.style.display = 'block';
        return;
    } else if (!emailRegex.test(emailInput)) {
        emailError.textContent = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
        emailError.style.display = 'block';
        return;
    }

    // Fehler ausblenden und zur nächsten Frage navigieren
    emailError.style.display = 'none';
    nextQuestion(11, 100); // Zur nächsten Frage navigieren und Fortschritt auf 100% aktualisieren
}

// Zusätzliche Funktion zur Zusammenfassung der Antworten
function generateSummary() {
    const summary = `
        <p><strong>PLZ:</strong> ${document.getElementById('plz').value}</p>
        <p><strong>Ort:</strong> ${document.getElementById('ort').value}</p>
        <p><strong>Straße:</strong> ${document.getElementById('strasse').value}</p>
        <p><strong>Hausnummer:</strong> ${document.getElementById('hausnummer').value}</p>
    `;
    document.getElementById('summary').innerHTML = summary;
}

// Initialisierung der Seite
document.addEventListener('DOMContentLoaded', () => {
    hideAllQuestions(); // Versteckt alle Fragen
    showQuestion(1); // Zeigt die erste Frage an
    updateProgressBar(0); // Fortschrittsanzeige auf 0% setzen

    // Mindestwerte für Datumsfelder setzen
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('start-date').setAttribute('min', today);
    document.getElementById('end-date').setAttribute('min', today);
});

</script>



</html>

<?php
get_footer();
?>


